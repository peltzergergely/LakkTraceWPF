﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace LakkTraceWPF.UnitTest
{
    [TestClass]
    public class ValidationTests
    {
        [TestMethod]
        public void TextValidationTest()
        {

        }
    }
}
